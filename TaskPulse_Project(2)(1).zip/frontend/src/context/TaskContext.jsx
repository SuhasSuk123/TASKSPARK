import { createContext,useContext } from 'react';
const TaskContext=createContext();
export const TaskProvider=({children})=><TaskContext.Provider value={{}}>{children}</TaskContext.Provider>;
export const useTasks=()=>useContext(TaskContext);
