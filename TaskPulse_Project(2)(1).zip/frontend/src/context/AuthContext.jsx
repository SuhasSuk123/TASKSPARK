import { createContext,useContext,useState } from 'react';
const AuthContext=createContext();
export const AuthProvider=({children})=>{const [user,setUser]=useState(null);const [loading]=useState(false);
const login=()=>{};const signup=()=>{};const logout=()=>{};return <AuthContext.Provider value={{user,loading,login,signup,logout}}>{children}</AuthContext.Provider>};
export const useAuth=()=>useContext(AuthContext);
