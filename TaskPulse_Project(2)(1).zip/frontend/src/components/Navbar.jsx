import { Moon, Sun, LogOut } from "lucide-react";
import { useAuth } from "../context/AuthContext.jsx";

export default function Navbar({ dark, setDark }) {
  const { user, logout } = useAuth();

  return (
    <div className="glass px-6 py-4 flex justify-between items-center">
      <h1 className="text-xl font-bold tracking-wide">
        Task<span className="text-cyan-400">Pulse</span>
      </h1>

      <div className="flex items-center gap-4">
        <div className="text-sm text-white/70">
          {user?.name} • <span className="text-cyan-400">{user?.role}</span>
        </div>

        <button className="btn-outline flex gap-2 items-center" onClick={() => setDark(!dark)}>
          {dark ? <Sun size={18} /> : <Moon size={18} />}
          {dark ? "Light" : "Dark"}
        </button>

        <button className="btn-primary flex gap-2 items-center" onClick={logout}>
          <LogOut size={18} /> Logout
        </button>
      </div>
    </div>
  );
}
