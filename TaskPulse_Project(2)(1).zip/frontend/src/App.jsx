import { Routes, Route } from "react-router-dom";
import Auth from "./pages/Auth.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Tasks from "./pages/Tasks.jsx";
import Logs from "./pages/Logs.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";
import Navbar from "./components/Navbar.jsx";
import { useEffect, useState } from "react";

export default function App() {
  const [dark, setDark] = useState(true);

  useEffect(() => {
    document.body.className = dark ? "bg-slate-950 text-white" : "bg-slate-100 text-black";
  }, [dark]);

  return (
    <Routes>
      <Route path="/auth" element={<Auth />} />
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <div className="p-6 max-w-6xl mx-auto space-y-6">
              <Navbar dark={dark} setDark={setDark} />
              <Dashboard />
            </div>
          </ProtectedRoute>
        }
      />
      <Route
        path="/tasks"
        element={
          <ProtectedRoute>
            <div className="p-6 max-w-6xl mx-auto space-y-6">
              <Navbar dark={dark} setDark={setDark} />
              <Tasks />
            </div>
          </ProtectedRoute>
        }
      />
      <Route
        path="/logs"
        element={
          <ProtectedRoute>
            <div className="p-6 max-w-6xl mx-auto space-y-6">
              <Navbar dark={dark} setDark={setDark} />
              <Logs />
            </div>
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}
