export default function Auth(){return <div className='p-10'>Auth Page</div>}
