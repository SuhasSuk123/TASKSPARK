export default function Logs(){return <div className='p-10'>Logs</div>}
