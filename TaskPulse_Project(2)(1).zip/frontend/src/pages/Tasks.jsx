export default function Tasks(){return <div className='p-10'>Tasks</div>}
