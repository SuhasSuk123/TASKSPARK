import express from "express";
import { signup, login, me } from "../controllers/auth.controller.js";
import auth from "../middleware/auth.js";
import { apiLimiter } from "../middleware/rateLimit.js";

const router = express.Router();
router.post("/signup", apiLimiter, signup);
router.post("/login", apiLimiter, login);
router.get("/me", auth, me);

export default router;
