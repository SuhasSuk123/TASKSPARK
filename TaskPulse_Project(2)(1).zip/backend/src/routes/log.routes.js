import express from "express";
import auth from "../middleware/auth.js";
import { apiLimiter } from "../middleware/rateLimit.js";
import { getTaskLogs } from "../controllers/log.controller.js";

const router = express.Router();
router.get("/task/:taskId", apiLimiter, auth, getTaskLogs);

export default router;
