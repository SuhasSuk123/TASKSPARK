import express from "express";
import auth from "../middleware/auth.js";
import { allowRoles } from "../middleware/rbac.js";
import { apiLimiter } from "../middleware/rateLimit.js";
import { createTask, assignedTasks, createdTasks, updateTask, deleteTask } from "../controllers/task.controller.js";

const router = express.Router();
router.post("/", apiLimiter, auth, allowRoles("manager"), createTask);
router.get("/assigned", apiLimiter, auth, assignedTasks);
router.get("/created", apiLimiter, auth, allowRoles("manager"), createdTasks);
router.patch("/:id", apiLimiter, auth, updateTask);
router.delete("/:id", apiLimiter, auth, allowRoles("manager"), deleteTask);

export default router;
