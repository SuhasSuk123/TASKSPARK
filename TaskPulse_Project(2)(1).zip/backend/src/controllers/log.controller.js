import ActivityLog from "../models/ActivityLog.js";

export const getTaskLogs = async (req, res) => {
  const logs = await ActivityLog.find({ taskId: req.params.taskId })
    .populate("performedBy", "name role")
    .sort({ createdAt: -1 });

  res.json(logs);
};
