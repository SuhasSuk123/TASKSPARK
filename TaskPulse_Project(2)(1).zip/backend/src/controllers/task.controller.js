import Task from "../models/Task.js";
import ActivityLog from "../models/ActivityLog.js";

const logAction = async (action, taskId, userId) => {
  await ActivityLog.create({ action, taskId, performedBy: userId });
};

export const createTask = async (req, res) => {
  const task = await Task.create({ ...req.body, createdBy: req.user._id });
  await logAction("Created Task", task._id, req.user._id);
  req.app.get("io")?.emit("taskCreated", task);
  res.json(task);
};

export const assignedTasks = async (req, res) => {
  const page = Number(req.query.page || 1);
  const limit = Number(req.query.limit || 10);
  const skip = (page - 1) * limit;

  const total = await Task.countDocuments({ assignedTo: req.user._id });
  const tasks = await Task.find({ assignedTo: req.user._id }).sort({ createdAt: -1 }).skip(skip).limit(limit);

  res.json({ tasks, total, page, pages: Math.ceil(total / limit) });
};

export const createdTasks = async (req, res) => {
  const tasks = await Task.find({ createdBy: req.user._id }).sort({ createdAt: -1 });
  res.json(tasks);
};

export const updateTask = async (req, res) => {
  const task = await Task.findById(req.params.id);
  if (!task) return res.status(404).json({ message: "Task not found" });

  if (req.user.role === "user") {
    if (String(task.assignedTo) !== String(req.user._id)) return res.status(403).json({ message: "Not your task" });
    if (!req.body.status) return res.status(403).json({ message: "User can only update status" });

    task.status = req.body.status;
    await task.save();
    await logAction("Updated Status", task._id, req.user._id);
  } else {
    Object.assign(task, req.body);
    await task.save();
    await logAction("Edited Task", task._id, req.user._id);
  }

  req.app.get("io")?.emit("taskUpdated", task);
  res.json(task);
};

export const deleteTask = async (req, res) => {
  const task = await Task.findById(req.params.id);
  if (!task) return res.status(404).json({ message: "Task not found" });

  await Task.deleteOne({ _id: task._id });
  await logAction("Deleted Task", task._id, req.user._id);

  req.app.get("io")?.emit("taskDeleted", task._id);
  res.json({ message: "Deleted successfully" });
};
